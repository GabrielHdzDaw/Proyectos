﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoCasa
{
    internal class Apartamento:Casa
    {
        public Apartamento():base(50)
        {

        }
    }
}
