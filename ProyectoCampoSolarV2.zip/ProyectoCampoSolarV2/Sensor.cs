﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoCampoSolar
{
    internal class Sensor:PlacaSolar
    {
        public Sensor(string nombre, int grados) : base(nombre, grados)
        {
        }

        
    }
}
