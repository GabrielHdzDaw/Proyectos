﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoCampoSolar
{
    internal class Distribuidor:Elemento
    {
        

        public Distribuidor(string nombre):base(nombre)
        {
            
        }
        
    }
}
