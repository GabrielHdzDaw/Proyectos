﻿/* Autor: gabhercol
/* Fecha: 3/10/2025 11:20:21 AM
/* Descripción: Manejo de ficheros 
*/
namespace ProyectoFicheros
{
    internal class Program
    {
        public static void Ejercicio1()
        {
            StreamWriter myFile = File.CreateText("../../../textFile1.txt");
            myFile.WriteLine("Hola");
            myFile.WriteLine("Adiós");
            myFile.Close();
        }
        public static void Ejercicio2()
        {
            StreamWriter myFile = new StreamWriter("../../../textFile2.txt");
            for (int i = 1; i <= 100; i++)
            {
                myFile.WriteLine($"Línea {i}");
            }
            myFile.Close();
        }

        public static void Ejercicio3()
        {
            using (StreamWriter myFile = new StreamWriter("../../../textFile3.txt"))
            {
                myFile.WriteLine($"Línea");
            }
        }

        public static bool EsPrimo(int num)
        {
            bool primo = true;
            for (int i = 2; i < num && num % i == 0; i++)
            {
                if (num % i == 0)
                {
                    primo = false;
                }
            }
            return primo;
        }

        public static void Ejercicio4()
        {
            using (StreamWriter myFile = new StreamWriter("../../../primos.txt"))
            {
                int i = 1;
                while (i < 50)
                {
                    if(EsPrimo(i))
                    {
                        myFile.WriteLine(i);
                    }
                    i++;
                }
            }
           
        }
        public static void Main(string[] args)
        {
            Ejercicio1();
            Ejercicio2();
            Ejercicio3();
            Ejercicio4();
        }
    }
}
